import { pgTable, serial, integer, text, varchar, numeric, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const tutoringStatusEnum = pgEnum("tutoring_status", [
  "pending", "accepted", "declined", "completed", "cancelled",
  "rescheduled_by_teacher", "rescheduled_by_student"
]);

export const tutoringRequestsTable = pgTable("tutoring_requests", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull().references(() => usersTable.id),
  teacherId: integer("teacher_id").notNull().references(() => usersTable.id),
  subject: varchar("subject", { length: 255 }).notNull(),
  topic: text("topic").notNull(),
  preferredAt: timestamp("preferred_at").notNull(),
  proposedAt: timestamp("proposed_at"),
  durationMinutes: integer("duration_minutes").notNull().default(60),
  message: text("message"),
  hourlyRate: numeric("hourly_rate", { precision: 10, scale: 2 }).notNull().default("0"),
  totalAmount: numeric("total_amount", { precision: 10, scale: 2 }).notNull().default("0"),
  currency: varchar("currency", { length: 10 }).notNull().default("LYD"),
  status: tutoringStatusEnum("status").notNull().default("pending"),
  meetingUrl: text("meeting_url"),
  paymentId: integer("payment_id"),
  studentRating: integer("student_rating"),
  studentReview: text("student_review"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type TutoringRequest = typeof tutoringRequestsTable.$inferSelect;
